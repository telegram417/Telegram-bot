# Anonymous Dating Bot 💌

Free 24/7 Telegram Bot Deployment Guide

## Steps to Deploy on Render.com
1. Upload this zip on [https://render.com](https://render.com)
2. Create **Web Service**
3. Add environment variable:
   - BOT_TOKEN = your telegram bot token
4. Start command:
   ```bash
   python main.py
   ```
